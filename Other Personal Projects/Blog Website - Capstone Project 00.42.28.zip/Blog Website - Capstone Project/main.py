import base64
import os
import ssl

from flask import Flask, render_template, request
import requests
import smtplib

posts = requests.get("https://api.npoint.io/c790b4d5cab58020d391").json()
requested_post = None

# Load credentials from environment variables or a configuration file
RECIPIENT_EMAIL = os.environ.get("RECIPIENT_EMAIL")
# RECIPIENT_PASSWORD = "avxb mryk rckh ehlx"
RECIPIENT_PASSWORD = "newConnection."

LIST_OF_RECIPIENTS = ["amiddabs93@gmail.com", "232a.dabor@gmail.com", "daboramidu93@gmail.com"]

app = Flask(__name__)


@app.route("/")
def get_all_posts():
    return render_template("index.html", all_posts=posts)


@app.route("/post/<int:index>")
def display_post(index):
    global posts
    global requested_post

    for blog_post in posts:
        if blog_post.get('id') == index:
            requested_post = blog_post

    return render_template("post.html", post=requested_post)


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/contact")
def contact():
    return render_template("forms/contact.html")


request_status = None


@app.route("/form-entry", methods=["POST"])
def fetch_data():
    global request_status

    if request.method == "POST":
        name = request.form["username"]
        email = request.form["email"]
        phone = request.form["phone"]
        message = request.form["message"]

        # Send email
        # send_email(name, email, phone, message)

        return render_template("forms/contact.html", message_sent=True)

    return render_template("forms/contact.html", message_sent=False)


def send_email(name, sender_email, phone, message):

    email_message = f"Subject: Blog Contact \n\n" \
                    f"Name: {name} \n" \
                    f"Email: {sender_email} \n" \
                    f"Phone: {phone} \n" \
                    f"Message: {message}"

    # context = ssl.create_default_context()

    with smtplib.SMTP("smtp.gmail.com") as connection:
        connection.starttls()
        connection.login(RECIPIENT_EMAIL, RECIPIENT_PASSWORD)
        connection.sendmail(sender_email, LIST_OF_RECIPIENTS, email_message)


if __name__ == "__main__":
    app.run(debug=True)
