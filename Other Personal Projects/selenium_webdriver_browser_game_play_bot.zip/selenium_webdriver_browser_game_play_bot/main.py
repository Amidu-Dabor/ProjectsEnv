from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

chrome_driver_path = "/Users/Courses and Tutorials/Courses/Python and Django/100 Days of Code The Complete Python Pro Bootcamp for 2022/[TutsNode.com] - 100 Days of Code The Complete Python Pro Bootcamp for 2022/48 Day 48 - Inter+ Selenium Webdriver Browser, Game Play Bot/chromedriver-mac-arm64/chromedriver"
chrome_driver_service = Service(chrome_driver_path)
driver = webdriver.Chrome(service=chrome_driver_service)

# driver.get("https://www.amazon.com/Instant-Pot-Ultra-Programmable-Sterilizer/dp/B06Y1MP2PY/ref=sr_1_7?crid=KWSSND4J6X9Y&keywords=instant%2Bpot%2Bduo%2Bevo%2Bplus&qid=1694722227&sprefix=instant%2Bpot%2Bdou%2Caps%2C389&sr=8-7&th=1")

# FIRST SOLUTION
driver.get("https://www.python.org/")
events = driver.find_elements(By.XPATH, '//*[@id="content"]/div/section/div[2]/div[2]/div/ul/li')

upcoming_events_list = {n: {'event_time': events[n].text.split("\n")[0], 'event_name': events[n].text.split("\n")[1]} for n in range(len(events))}
print(upcoming_events_list)


# SECOND SOLUTION
# event_times = driver.find_elements(By.CSS_SELECTOR, 'div.event-widget time')
# event_names = driver.find_elements(By.CSS_SELECTOR, 'div.event-widget li a')
# events_dic = {}
#
# for n in range(len(event_times)):
#     events_dic[n] = {
#         'event_time': event_times[n].text,
#         'event_name': event_names[n].text
#     }
# print(events_dic)


# ThIRD SOLUTION
# upcoming_events_list = []

# for event in events:
#     # event_time = event.find_element(By.XPATH, './/time').text
#     # event_name = event.find_element(By.XPATH, './/a').text
#
    # event_time = event.find_element(By.CSS_SELECTOR, 'div.event-widget time').text
    # event_name = event.find_element(By.CSS_SELECTOR, 'div.event-widget li a').text
#
#     event_data = {'time': event_time, 'name': event_name}
#     upcoming_events_list.append(event_data)
#
# driver.close()
#
# for event_data in upcoming_events_list:
#     print(event_data)




