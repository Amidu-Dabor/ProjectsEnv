version https://git-lfs.github.com/spec/v1
oid sha256:102a608f69c74f85a8e478dd88a939a429e819d8cefc3c1ef4a58a2c90e4a4f2
size 1714
