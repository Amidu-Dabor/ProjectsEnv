﻿CREATE TABLE [dbo].[PhonebookTable]
(
	[First_Name] VARCHAR(50) NULL, 
    [Last_Name] VARCHAR(50) NULL, 
    [Phone_Number] VARCHAR(50) NULL, 
    [Email_Address] VARCHAR(50) NULL, 
    [Home_Address] VARCHAR(50) NULL 
)
