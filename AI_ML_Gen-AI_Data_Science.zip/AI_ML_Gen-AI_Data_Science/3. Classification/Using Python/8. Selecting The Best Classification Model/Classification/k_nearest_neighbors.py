version https://git-lfs.github.com/spec/v1
oid sha256:69dc4997dced31a60f7b0c5cf82c2fa9fb098d51f0a6fe7d678eb08f423b3396
size 1060
