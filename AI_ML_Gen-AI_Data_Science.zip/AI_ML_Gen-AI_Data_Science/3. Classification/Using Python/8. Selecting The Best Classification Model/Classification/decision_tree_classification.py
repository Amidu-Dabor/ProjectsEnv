version https://git-lfs.github.com/spec/v1
oid sha256:a4d491e6462bff9b7b764bf916e7b66798779cc1a2636d7433250a6894b9df55
size 1080
