version https://git-lfs.github.com/spec/v1
oid sha256:3ce4da6b619b922adae5399b12495784d34aefdd8c0a8a0971d647398cb8fa43
size 1453
